// header.js - VÉGLEGES MEGOLDÁS
document.addEventListener('DOMContentLoaded', function() {
    console.log('Header JS loaded - Final solution');

    // Profil dropdown kezelése (asztali)
    const profileDropdown = document.querySelector('.header_profile_dropdown');
    const profileLink = document.querySelector('.profile-link');
    const dropdownMenu = document.querySelector('.header_dropdown_menu');
    
    if (profileDropdown && profileLink && dropdownMenu) {
        profileLink.addEventListener('click', function(e) {
            e.preventDefault();
            dropdownMenu.classList.toggle('active');
            e.stopPropagation();
        });
        
        document.addEventListener('click', function(e) {
            if (!profileDropdown.contains(e.target)) {
                dropdownMenu.classList.remove('active');
            }
        });
    }

    // Mobil hamburger menü funkcionalitás
    const mobileMenuToggle = document.querySelector('.mobile-menu-toggle');
    const mobileMenuContent = document.querySelector('.mobile-menu-content');
    const mobileCloseButton = document.querySelector('.mobile-close-button');
    
    if (mobileMenuToggle && mobileMenuContent && mobileCloseButton) {
        console.log('Mobile menu elements found');
        
        // Overlay létrehozása
        const overlay = document.createElement('div');
        overlay.className = 'mobile-menu-overlay';
        document.body.appendChild(overlay);
        
        // Menü megnyitása
        const openMenu = function() {
            console.log('Opening menu');
            mobileMenuToggle.classList.add('active');
            mobileMenuContent.classList.add('active');
            overlay.classList.add('active');
            document.body.style.overflow = 'hidden';
        };
        
        // Menü bezárása
        const closeMenu = function() {
            console.log('Closing menu');
            mobileMenuToggle.classList.remove('active');
            mobileMenuContent.classList.remove('active');
            overlay.classList.remove('active');
            document.body.style.overflow = '';
            
            // Profil almenü bezárása
            const mobileProfileSection = document.querySelector('.mobile-profile-section');
            if (mobileProfileSection) {
                mobileProfileSection.classList.remove('active');
            }
        };
        
        // Hamburger gomb eseménykezelő
        mobileMenuToggle.addEventListener('click', function(e) {
            console.log('Hamburger clicked');
            e.stopPropagation();
            if (mobileMenuContent.classList.contains('active')) {
                closeMenu();
            } else {
                openMenu();
            }
        });
        
        // Bezárás gomb eseménykezelő
        mobileCloseButton.addEventListener('click', function(e) {
            console.log('Close button clicked');
            e.stopPropagation();
            closeMenu();
        });
        
        // Overlay kattintás - menü bezárása
        overlay.addEventListener('click', closeMenu);
        
        // ESC billentyű - menü bezárása
        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape' && mobileMenuContent.classList.contains('active')) {
                closeMenu();
            }
        });
        
        // Mobil profil menü kezelése
        const mobileProfileHeader = document.querySelector('.mobile-profile-header');
        const mobileProfileSection = document.querySelector('.mobile-profile-section');
        
        if (mobileProfileHeader && mobileProfileSection) {
            mobileProfileHeader.addEventListener('click', function(e) {
                console.log('Profile header clicked');
                e.stopPropagation();
                mobileProfileSection.classList.toggle('active');
            });
            
            // Profil menü bezárása, ha kattintanak máshova a menüben
            mobileMenuContent.addEventListener('click', function(e) {
                if (!e.target.closest('.mobile-profile-section') && mobileProfileSection.classList.contains('active')) {
                    mobileProfileSection.classList.remove('active');
                }
            });
        }
        
        // Link kattintás - menü bezárása
        mobileMenuContent.addEventListener('click', function(e) {
            // Ha profil headerre kattintunk, ne csináljon semmit
            if (e.target.closest('.mobile-profile-header')) {
                return;
            }
            
            // Ha bezárás gombra kattintunk, ne csináljon semmit (már kezeltük)
            if (e.target.closest('.mobile-close-button')) {
                return;
            }
            
            // Ha mobil menü fejléc (logo) kattintás, ne zárja be a menüt
            if (e.target.closest('.mobile-logo-link')) {
                // A link alapértelmezetten a főoldalra visz, nem kell bezárni a menüt
                return;
            }
            
            // Ha profil almenü linkre kattintunk, zárja be a teljes menüt
            if (e.target.tagName === 'A' && e.target.closest('.mobile-profile-menu')) {
                closeMenu();
                return;
            }
            
            // Ha sima menülinkre kattintunk, zárja be a menüt
            if (e.target.tagName === 'A') {
                closeMenu();
            }
        });
    } else {
        console.log('Mobile menu elements NOT found:', {
            mobileMenuToggle,
            mobileMenuContent,
            mobileCloseButton
        });
    }
});