// Profilkép előnézet
function previewImage(input) {
    if (input.files && input.files[0]) {
        const reader = new FileReader();
        
        reader.onload = function(e) {
            document.getElementById('profile_image_preview').src = e.target.result;
        }
        
        reader.readAsDataURL(input.files[0]);
    }
}

// Változások követése
let formModified = false;
let modifiedFieldsCount = 0;

function setFormModified(state, count = 0) {
    formModified = state;
    modifiedFieldsCount = count;
    
    // Frissítjük a folyamatban lévő módosításokat
    updateFolyamatbanUzenet(count);
}

function checkFormChanges() {
    const form = document.getElementById('profileForm');
    if (!form) return;
    
    const inputs = form.querySelectorAll('input, select, textarea');
    let changedCount = 0;
    
    inputs.forEach(input => {
        if (input.type === 'file') {
            if (input.files.length > 0) {
                changedCount++;
            }
        } else if (input.defaultValue !== input.value) {
            changedCount++;
        }
    });
    
    setFormModified(changedCount > 0, changedCount);
    return changedCount > 0;
}

function updateFolyamatbanUzenet(count) {
    // Eltávolítjuk a régi folyamatban üzenetet
    const regiFolyamatban = document.querySelector('.folyamatban');
    if (regiFolyamatban) {
        regiFolyamatban.remove();
    }
    
    // Ha van módosítás, hozzáadjuk az új üzenetet
    if (count > 0) {
        const folyamatbanDiv = document.createElement('div');
        folyamatbanDiv.className = 'folyamatban';
        folyamatbanDiv.innerHTML = `<p>Módosítás alatt: ${count} mező</p>`;
        
        // Beszúrjuk a hiba/siker üzenetek után
        const sikerDiv = document.querySelector('.siker');
        const hibaDiv = document.querySelector('.hiba');
        
        if (sikerDiv) {
            sikerDiv.after(folyamatbanDiv);
        } else if (hibaDiv) {
            hibaDiv.after(folyamatbanDiv);
        } else {
            // Ha nincs hiba/siker üzenet, a profil információk után szúrjuk be
            const profileInfo = document.querySelector('.profile-header-container');
            profileInfo.after(folyamatbanDiv);
        }
    }
}

// Oldal elhagyásának figyelése
function handleBeforeUnload(event) {
    if (formModified) {
        event.preventDefault();
        event.returnValue = `Nem mentett módosításaid vannak a profilodban (${modifiedFieldsCount} mező). Biztosan el akarod hagyni az oldalt?`;
        return event.returnValue;
    }
}

// Link kattintások kezelése
function handleLinkClick(event) {
    if (formModified) {
        const confirmation = confirm(`Nem mentett módosításaid vannak a profilodban (${modifiedFieldsCount} mező). Biztosan el akarod hagyni az oldalt? A módosításaid elvesznek.`);
        if (!confirmation) {
            event.preventDefault();
            event.stopPropagation();
            return false;
        }
    }
}

// Vármegye validáció és dinamikus opció hozzáadása
function initCountyValidation() {
    const varmegyeSelect = document.getElementById('varmegye');
    if (!varmegyeSelect) return;
    
    // Vármegyék listája
    const varmegyek = [
        'Budapest',
        'Bács-Kiskun',
        'Baranya',
        'Békés',
        'Borsod-Abaúj-Zemplén',
        'Csongrád-Csanád',
        'Fejér',
        'Győr-Moson-Sopron',
        'Hajdú-Bihar',
        'Heves',
        'Jász-Nagykun-Szolnok',
        'Komárom-Esztergom',
        'Nógrád',
        'Pest',
        'Somogy',
        'Szabolcs-Szatmár-Bereg',
        'Tolna',
        'Vas',
        'Veszprém',
        'Zala'
    ];
    
    // Ellenőrizzük a jelenlegi értéket
    const currentValue = varmegyeSelect.value;
    
    // Ha a jelenlegi érték nem üres és nincs a listában, hozzáadjuk a "Nincs ilyen" opciót
    if (currentValue && !varmegyek.includes(currentValue) && currentValue !== "no_match") {
        // Először távolítsuk el a "Nincs ilyen" opciót, ha már létezik
        const existingNoMatch = varmegyeSelect.querySelector('option[value="no_match"]');
        if (existingNoMatch) {
            existingNoMatch.remove();
        }
        
        // Adjuk hozzá az új "Nincs ilyen" opciót
        const noMatchOption = document.createElement('option');
        noMatchOption.value = "no_match";
        noMatchOption.textContent = `Nincs ilyen: ${currentValue}`;
        noMatchOption.style.color = '#ff4444';
        noMatchOption.style.fontStyle = 'italic';
        varmegyeSelect.appendChild(noMatchOption);
        
        // Állítsuk be kiválasztottnak
        varmegyeSelect.value = "no_match";
    }
}

// Inicializálás
document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('profileForm');
    if (!form) return;
    
    // Profilkép eseménykezelők - dupla kattintás javítása
    const profilePic = document.querySelector('.profile_pic');
    const editIcon = document.querySelector('.edit_icon');
    const fileInput = document.getElementById('profilkep');
    
    // Csak a ceruza ikonra kattintás nyissa meg a fájlválasztót
    if (editIcon) {
        editIcon.addEventListener('click', function(e) {
            e.stopPropagation();
            fileInput.click();
        });
    }
    
    // A profilkép többi részére kattintva is megnyílik a fájlválasztó
    if (profilePic) {
        profilePic.addEventListener('click', function(e) {
            if (!e.target.closest('.edit_icon')) {
                fileInput.click();
            }
        });
    }
    
    // Profilkép változás kezelése
    if (fileInput) {
        fileInput.addEventListener('change', function() {
            previewImage(this);
            checkFormChanges();
        });
    }
    
    // Alapértelmezett értékek beállítása
    const inputs = form.querySelectorAll('input, select, textarea');
    inputs.forEach(input => {
        if (input.type !== 'file') {
            input.defaultValue = input.value;
        }
    });
    
    // Eseményfigyelők
    inputs.forEach(input => {
        input.addEventListener('input', checkFormChanges);
        input.addEventListener('change', checkFormChanges);
    });
    
    // Form reset
    form.addEventListener('reset', function() {
        setTimeout(() => {
            setFormModified(false, 0);
            // Alapértelmezett értékek frissítése
            inputs.forEach(input => {
                if (input.type !== 'file') {
                    input.defaultValue = input.value;
                }
            });
        }, 0);
    });
    
    // Form submit
    form.addEventListener('submit', function() {
        setFormModified(false, 0);
    });
    
    // Navigáció figyelése
    window.addEventListener('beforeunload', handleBeforeUnload);
    
    // Linkek figyelése
    document.addEventListener('click', function(e) {
        const link = e.target.closest('a');
        if (link && link.href && !link.href.includes('javascript:')) {
            handleLinkClick(e);
        }
    });
    
    // Visszaállítás gomb
    const resetBtn = document.querySelector('.reset-btn');
    if (resetBtn) {
        resetBtn.addEventListener('click', function(e) {
            if (formModified) {
                const confirmation = confirm(`Biztosan vissza szeretnéd állítani az összes módosítást? (${modifiedFieldsCount} mező)`);
                if (!confirmation) {
                    e.preventDefault();
                }
            }
        });
    }
    
    // Vármegye validáció inicializálása
    initCountyValidation();
    
    // Vármegye select változás kezelése
    const varmegyeSelect = document.getElementById('varmegye');
    if (varmegyeSelect) {
        varmegyeSelect.addEventListener('change', function() {
            // Ha a "Nincs ilyen" opció van kiválasztva, akkor állítsuk vissza üresre
            if (this.value === "no_match") {
                // Kérjük meg a felhasználót, hogy válasszon a listából
                alert('Kérjük, válasszon a listából egy érvényes vármegyét!');
                this.value = "";
                
                // Távolítsuk el a "Nincs ilyen" opciót
                const noMatchOption = this.querySelector('option[value="no_match"]');
                if (noMatchOption) {
                    noMatchOption.remove();
                }
            }
            checkFormChanges();
        });
    }
});