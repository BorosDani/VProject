<?php
require_once 'functions.php'; // Feltételezve, hogy a functions.php már betöltődik
?>
<div class='footer_box'>
    <div class='footer_left'>
        <p>Elérhetőség</p>
        <p>Villám Meló Közösség</p>
        <p>Email: info@villammelo.hu</p>
    </div>

    <div class='footer_right'>
        <?php 
        $footerStats = getFooterStats(); 
        ?>
        <p>Tagok száma: <strong><?php echo $footerStats['tagok_szama']; ?></strong></p>
        <p>Munkák száma: <strong><?php echo $footerStats['munkak_szama']; ?></strong></p>
        <p>Elégedett ügyfelek száma: <strong><?php echo $footerStats['elegedett_ugyfelek_szama']; ?></strong></p>
    </div>

    <div class='footer_mid_bottom'>
        <footer>
            <div class="social-icons">
                <a href="https://www.instagram.com/h4nzo_art/#" target="_blank">
                    <img src="assets/images/vm_images/instagram2.jpg" alt="Instagram">
                </a>
                <a href="https://facebook.com" target="_blank">
                    <img src="assets/images/vm_images/facebook.png" alt="Facebook">
                </a>
            </div>
            <p>&copy; <?= date('Y') ?> Villám Meló. Minden jog fenntartva.</p>
            <p>
                <a href="<?= base_url("contact")?>">GYIK</a> | 
                <a href="<?= base_url("about")?>">Tudj meg rólunk többet</a> | 
                <a href="<?= base_url("jobs")?>">Keress munkákat</a>
            </p>
        </footer>
    </div>
</div>
</body>
</html>