<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?= base_url('assets/css/style.css') ?>">
    <title>404 - Villám meló</title>
</head>
<body>
    <h1>Sajnos nem találtuk a kérelmedet!</h1>
</body>
</html>