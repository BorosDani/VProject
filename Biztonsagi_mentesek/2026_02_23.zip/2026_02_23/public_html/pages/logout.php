<?php
    logout();
?>